﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task3._1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                vehicle v = new vehicle(120);
                v.currentspeed = 40;
                v.IncreaseSpeed(100);
            }
            catch (SpeedMoreThanMaximumSpeedException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
    public class vehicle
    {
        public int currentspeed { get; set; }
        public int maximumspeed { get; set; }
        public vehicle(int maxi)
        {
            maximumspeed = maxi;
        }
        public void IncreaseSpeed(int speed)
        {
            if (currentspeed + speed > maximumspeed)
            {
                throw new SpeedMoreThanMaximumSpeedException("speed is more than maaimum speed");
            }
            currentspeed = currentspeed + speed;
            Console.WriteLine(currentspeed);
        }
       
    
    }
    public class SpeedMoreThanMaximumSpeedException : ApplicationException
    {
    public SpeedMoreThanMaximumSpeedException(string msg):base(msg)
    {
        
    }
}
}
