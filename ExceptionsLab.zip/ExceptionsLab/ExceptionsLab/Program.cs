﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionsLab
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a mobile no");
            string mno=(Console.ReadLine());
            try
            {
                Console.WriteLine( mobile_number(mno));
            }
            catch(InvalidMobileNumberException ex)
            {
                Console.WriteLine(ex.Message);
            }


        }
        public static string mobile_number(string mno)
        {
            foreach (var i in mno)
            {
                if (!char.IsDigit(i))
                {
                    throw new InvalidMobileNumberException("mno is invalid");
                }
            }
            if (mno.Length !=10 || (mno[0]-'0')!=9||mno==null)
            {
                throw new InvalidMobileNumberException("mno is invalid");
            }
            else
            {
                return "valid";
            }
            
        }
        public class InvalidMobileNumberException : ApplicationException
        {
            public InvalidMobileNumberException(string msg):base(msg) 
            { 

            }
            
        }

    }
}
