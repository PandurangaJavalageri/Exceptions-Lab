﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try

            {

                StreamReader sr = File.OpenText("abc.txt"); 
                int input1, input2, output;

                input1 = int.Parse(sr.ReadLine());

                input2 = int.Parse(sr.ReadLine());

                output = input1 / input2;
                Console.WriteLine(output);
                sr.Close();

            }

            catch (OverflowException ex)

            {

                Console.WriteLine(ex.Message);

            }

            catch (DivideByZeroException ex)

            {
                Console.WriteLine(ex.Message);
            }
            catch(FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(DirectoryNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
